import React from 'react';
import './PhaseC.css';

const PhaseC = ({ controls, onChange, onExport, isProcessing, hasDocuments, conversations = [] }) => {
  const handleSliderChange = (key, value) => {
    onChange({ ...controls, [key]: value });
  };

  const handleSelectChange = (key, value) => {
    onChange({ ...controls, [key]: value });
  };

  const toneOptions = [
    { value: 'professional', label: 'Professional' },
    { value: 'friendly', label: 'Friendly' },
    { value: 'casual', label: 'Casual' },
    { value: 'formal', label: 'Formal' },
    { value: 'empathetic', label: 'Empathetic' },
    { value: 'authoritative', label: 'Authoritative' }
  ];

  // Get the latest conversation or create a sample one
  const displayConversation = conversations.length > 0 
    ? conversations[conversations.length - 1]
    : null;

  return (
    <div className="phase-c">
      <div className="phase-header">
        <h2>Phase C: Agent Controls</h2>
        <p>Customize behavior and preview conversations</p>
      </div>

      {!hasDocuments ? (
        <div className="empty-state">
          <div className="empty-icon">🎛️</div>
          <p>Submit documents to unlock agent controls</p>
        </div>
      ) : (
        <>
          <div className="phase-c-content">
            <div className="controls-column">
              <h3>🎛️ Controls</h3>
              
              <div className="control-group compact">
                <label className="control-label">
                  <span>Tone</span>
                  <span className="control-value">{controls.tone}</span>
                </label>
                <select
                  className="control-select"
                  value={controls.tone}
                  onChange={(e) => handleSelectChange('tone', e.target.value)}
                >
                  {toneOptions.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>

              <div className="control-group compact">
                <label className="control-label">
                  <span>Formality</span>
                  <span className="control-value">{controls.formality}%</span>
                </label>
                <input
                  type="range"
                  className="control-slider"
                  min="0"
                  max="100"
                  value={controls.formality}
                  onChange={(e) => handleSliderChange('formality', parseInt(e.target.value))}
                />
              </div>

              <div className="control-group compact">
                <label className="control-label">
                  <span>Verbosity</span>
                  <span className="control-value">{controls.verbosity}%</span>
                </label>
                <input
                  type="range"
                  className="control-slider"
                  min="0"
                  max="100"
                  value={controls.verbosity}
                  onChange={(e) => handleSliderChange('verbosity', parseInt(e.target.value))}
                />
              </div>

              <div className="control-group compact">
                <label className="control-label">
                  <span>Empathy</span>
                  <span className="control-value">{controls.empathy}%</span>
                </label>
                <input
                  type="range"
                  className="control-slider"
                  min="0"
                  max="100"
                  value={controls.empathy}
                  onChange={(e) => handleSliderChange('empathy', parseInt(e.target.value))}
                />
              </div>

              <div className="control-group compact">
                <label className="control-label">
                  <span>Proactivity</span>
                  <span className="control-value">{controls.proactivity}%</span>
                </label>
                <input
                  type="range"
                  className="control-slider"
                  min="0"
                  max="100"
                  value={controls.proactivity}
                  onChange={(e) => handleSliderChange('proactivity', parseInt(e.target.value))}
                />
              </div>

              <div className="control-group compact">
                <label className="control-label">
                  <span>Creativity</span>
                  <span className="control-value">{controls.creativity}%</span>
                </label>
                <input
                  type="range"
                  className="control-slider"
                  min="0"
                  max="100"
                  value={controls.creativity}
                  onChange={(e) => handleSliderChange('creativity', parseInt(e.target.value))}
                />
              </div>

              <div className="control-group compact">
                <label className="control-label">
                  <span>Technical</span>
                  <span className="control-value">{controls.technicalDepth}%</span>
                </label>
                <input
                  type="range"
                  className="control-slider"
                  min="0"
                  max="100"
                  value={controls.technicalDepth}
                  onChange={(e) => handleSliderChange('technicalDepth', parseInt(e.target.value))}
                />
              </div>

              <button
                className="export-button compact"
                onClick={onExport}
                disabled={isProcessing}
              >
                📥 Export Framework
              </button>
            </div>

            <div className="chat-column">
              <h3>💬 Conversation Preview</h3>
              {displayConversation ? (
                <div className="imessage-chat">
                  <div className="chat-header">
                    <div className="chat-title">{displayConversation.scenarioTitle || 'Conversation'}</div>
                    <button className="play-audio-btn" title="Play conversation">
                      🔊
                    </button>
                  </div>
                  <div className="chat-messages">
                    {displayConversation.messages && displayConversation.messages.map((msg, idx) => (
                      <div
                        key={idx}
                        className={`chat-bubble ${msg.speaker === 'PersonaUser' ? 'user' : 'agent'}`}
                      >
                        <div className="bubble-content">
                          {msg.text}
                        </div>
                        <div className="bubble-time">
                          {msg.speaker === 'PersonaUser' ? 'User' : 'Agent'}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="no-conversation">
                  <div className="empty-icon">💭</div>
                  <p>Select a scenario in Phase B to see a conversation preview</p>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default PhaseC;
