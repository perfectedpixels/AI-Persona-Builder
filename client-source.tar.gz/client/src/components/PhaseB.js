import React, { useState } from 'react';
import './PhaseB.css';

const PhaseB = ({ scenarios = [], conversations = [], onScenarioSelect, isProcessing, documents, processedData }) => {
  const [selectedScenario, setSelectedScenario] = useState(null);
  const [userInput, setUserInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  const handleScenarioClick = (scenario) => {
    setSelectedScenario(scenario);
    onScenarioSelect(scenario.id);
  };

  const handleUserInterrupt = async () => {
    if (!userInput.trim()) return;

    // Send user interruption to backend
    try {
      const response = await fetch('/api/abm/user-interrupt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          input: userInput,
          currentConversation: conversations[conversations.length - 1],
          documents
        })
      });

      await response.json();
      // Update conversation with new exchange
      setUserInput('');
    } catch (error) {
      console.error('Error processing user input:', error);
    }
  };

  const handleVoiceInput = () => {
    setIsRecording(!isRecording);
    // TODO: Implement voice recording
  };

  return (
    <div className="phase-b">
      <div className="phase-header">
        <h2>Phase B: Conversation Playground</h2>
        <p>Explore scenarios and test agent interactions</p>
      </div>

      {!documents.productProposal ? (
        <div className="empty-state">
          <div className="empty-icon">📋</div>
          <p>Submit your documents in Phase A to generate scenarios</p>
        </div>
      ) : scenarios.length === 0 && !isProcessing ? (
        <div className="empty-state">
          <div className="empty-icon">⏳</div>
          <p>Processing your documents...</p>
        </div>
      ) : (
        <>
          <div className="scenarios-section">
            <h3>Suggested Scenarios</h3>
            <div className="scenarios-grid">
              {scenarios.map((scenario, idx) => (
                <div
                  key={idx}
                  className={`scenario-card ${selectedScenario?.id === scenario.id ? 'selected' : ''}`}
                  onClick={() => handleScenarioClick(scenario)}
                >
                  <div className="scenario-number">{idx + 1}</div>
                  <div className="scenario-title">{scenario.title}</div>
                  <div className="scenario-description">{scenario.description}</div>
                </div>
              ))}
            </div>
          </div>

          {processedData && (
            <div className="reasoning-section">
              <h3>📊 Document Analysis</h3>
              <div className="reasoning-content">
                <div className="reasoning-block">
                  <h4>Product Understanding</h4>
                  <div className="reasoning-item">
                    <strong>What:</strong> {processedData.product?.what || 'Not specified'}
                  </div>
                  <div className="reasoning-item">
                    <strong>Who:</strong> {processedData.product?.who || 'Not specified'}
                  </div>
                  <div className="reasoning-item">
                    <strong>Why:</strong> {processedData.product?.why || 'Not specified'}
                  </div>
                </div>

                <div className="reasoning-block">
                  <h4>User Persona Insights</h4>
                  <div className="reasoning-item">
                    <strong>Name:</strong> {processedData.persona?.name || 'Not specified'}
                  </div>
                  <div className="reasoning-item">
                    <strong>Technical Level:</strong> {processedData.persona?.technicalLevel || 'Not specified'}
                  </div>
                  {processedData.persona?.goals && processedData.persona.goals.length > 0 && (
                    <div className="reasoning-item">
                      <strong>Key Goals:</strong>
                      <ul>
                        {processedData.persona.goals.slice(0, 3).map((goal, idx) => (
                          <li key={idx}>{goal}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {processedData.persona?.painPoints && processedData.persona.painPoints.length > 0 && (
                    <div className="reasoning-item">
                      <strong>Pain Points:</strong>
                      <ul>
                        {processedData.persona.painPoints.slice(0, 3).map((pain, idx) => (
                          <li key={idx}>{pain}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                <div className="reasoning-block">
                  <h4>Agent Configuration</h4>
                  <div className="reasoning-item">
                    <strong>Purpose:</strong> {processedData.agent?.purpose || 'Not specified'}
                  </div>
                  <div className="reasoning-item">
                    <strong>Personality:</strong> {processedData.agent?.personality || 'Not specified'}
                  </div>
                  <div className="reasoning-item">
                    <strong>Tone:</strong> {processedData.agent?.tone || 'Not specified'}
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="user-input-section">
            <h3>Add Your Scenario</h3>
            <div className="input-container">
              <textarea
                className="user-input-textarea"
                placeholder="Describe a scenario you want to see play out between PersonaUser and AgentLLM..."
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                rows={3}
              />
              <div className="input-actions">
                <button
                  className={`voice-btn ${isRecording ? 'recording' : ''}`}
                  onClick={handleVoiceInput}
                  title="Voice input"
                >
                  {isRecording ? '⏹️ Stop' : '🎤 Voice'}
                </button>
                <button
                  className="send-btn"
                  onClick={handleUserInterrupt}
                  disabled={!userInput.trim() || isProcessing}
                >
                  ➤ Send
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default PhaseB;
