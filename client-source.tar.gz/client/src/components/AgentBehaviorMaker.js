import React, { useState } from 'react';
import PhaseA from './PhaseA';
import PhaseB from './PhaseB';
import PhaseC from './PhaseC';
import ProcessingStatus from './ProcessingStatus';
import './AgentBehaviorMaker.css';

const AgentBehaviorMaker = () => {
  const [documents, setDocuments] = useState({
    productProposal: null,
    userPersona: null,
    agentFramework: null
  });

  const [processedData, setProcessedData] = useState(null); // Store extracted reasoning
  const [scenarios, setScenarios] = useState([]);
  const [agentControls, setAgentControls] = useState({
    tone: 'professional',
    formality: 50,
    verbosity: 50,
    empathy: 70,
    proactivity: 50,
    creativity: 50,
    technicalDepth: 50
  });

  const [conversations, setConversations] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState(null);

  const handleDocumentsSubmit = async (docs) => {
    setIsProcessing(true);
    setDocuments(docs);
    setProcessingStatus({ currentStep: 'reading', message: 'Reading your documents...' });
    
    try {
      // Step 1: Reading (already done in PhaseA)
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setProcessingStatus({ currentStep: 'extracting', message: 'Extracting key information...' });
      
      // Process documents and generate scenarios
      const response = await fetch('/api/abm/process-documents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(docs)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to process documents');
      }
      
      setProcessingStatus({ currentStep: 'analyzing', message: 'Analyzing product and persona...' });
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setProcessingStatus({ currentStep: 'generating', message: 'Generating scenarios...' });
      
      const data = await response.json();
      
      setProcessingStatus({ currentStep: 'complete', message: 'All done!' });
      setScenarios(data.scenarios);
      setProcessedData(data.processedData); // Store the extracted reasoning
      
      // Clear status after a moment
      setTimeout(() => setProcessingStatus(null), 2000);
    } catch (error) {
      console.error('Error processing documents:', error);
      setProcessingStatus({ 
        currentStep: 'error', 
        error: error.message,
        details: { error: error.toString() }
      });
      // Don't clear error status automatically
    } finally {
      setIsProcessing(false);
    }
  };

  const handleScenarioSelect = async (scenarioId) => {
    setIsProcessing(true);
    
    try {
      const response = await fetch('/api/abm/generate-conversation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenarioId,
          documents,
          agentControls
        })
      });
      
      const data = await response.json();
      setConversations(prev => [...prev, data.conversation]);
    } catch (error) {
      console.error('Error generating conversation:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleControlsChange = async (newControls) => {
    setAgentControls(newControls);
    
    // Real-time refresh of conversations
    if (conversations.length > 0) {
      setIsProcessing(true);
      try {
        const response = await fetch('/api/abm/refresh-conversations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            documents,
            agentControls: newControls,
            existingConversations: conversations
          })
        });
        
        const data = await response.json();
        setConversations(data.conversations);
      } catch (error) {
        console.error('Error refreshing conversations:', error);
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleExportFramework = async () => {
    try {
      const response = await fetch('/api/abm/export-framework', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          documents,
          agentControls,
          conversations
        })
      });
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'updated-agent-framework.txt';
      a.click();
    } catch (error) {
      console.error('Error exporting framework:', error);
    }
  };

  return (
    <div className="agent-behavior-maker">
      <div className="abm-header">
        <h1>🤖 Agent Behavior Maker</h1>
        <p>Design and test LLM behaviors for your product</p>
      </div>

      {processingStatus && <ProcessingStatus status={processingStatus} />}

      {!processingStatus || processingStatus.currentStep === 'error' ? (
        <div className="abm-container">
          <PhaseA 
            onSubmit={handleDocumentsSubmit}
            isProcessing={isProcessing}
          />
          
          <PhaseB 
            scenarios={scenarios}
            conversations={conversations}
            onScenarioSelect={handleScenarioSelect}
            isProcessing={isProcessing}
            documents={documents}
            processedData={processedData}
          />
          
          <PhaseC 
            controls={agentControls}
            onChange={handleControlsChange}
            onExport={handleExportFramework}
            isProcessing={isProcessing}
            hasDocuments={!!documents.productProposal}
            conversations={conversations}
          />
        </div>
      ) : null}
    </div>
  );
};

export default AgentBehaviorMaker;
